To install nXhtml put this in your .emacs:

   (load "YOUR-PATH-TO/nxhtml/autostart.el")

where autostart.el is the file in the same directory as this
readme.txt file.

Note 1: If you are using Emacs+EmacsW32 then nXhtml is already
installed.

Note 2: If you are using Emacs 22 then you need to install nXml
separately. (It is included in Emacs 23.)

This is a temporary copy for my changes of company-mode for nXhtml.

Note 1: I have got a message that it does not work with etags.

Note 2: If you want to use the original company-mode you may have to
change nxhtml/autostart.el to avoid adding this company-mode to
load-path.

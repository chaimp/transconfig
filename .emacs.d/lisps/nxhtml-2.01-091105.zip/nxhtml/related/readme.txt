This subdir (related/) contains files that are taken from different
places and are maybe modified to work with nXhtml.

Please notice that major mode that are used with mumamo-mode must be a
bit more carefully written. One problem I have noticed is that some
major modes requuires that buffer-file-name is non-nil. That
assumption does not work when mumamo-mode is used!

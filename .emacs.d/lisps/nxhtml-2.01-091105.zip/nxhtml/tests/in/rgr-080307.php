<div src="hello"></div>
<img alt="angry" src="hello.gif"/>

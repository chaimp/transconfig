<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node BACKGROUND_COLOR="#00bfff" CREATED="1248161883687" ID="ID_4621171" MODIFIED="1248162997000" TEXT="test.org">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      --org-mode: WHOLE FILE
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1248161883687" MODIFIED="1248161883687" POSITION="left" TEXT="Bonjour">
<node CREATED="1248161883687" MODIFIED="1248161883687" TEXT="Ceci est un test">
<node BACKGROUND_COLOR="#eeee00" CREATED="1248161883687" MODIFIED="1248161883687" STYLE="bubble">
<richcontent TYPE="NODE"><html>
<head>
<style type="text/css">
<!--
p { margin-top: 0 }
-->
</style>
</head>
<body>
<p><br/> lkxjdflkdsz _lskfdsdf_ alskdjf<br/></p>
</body>
</html></richcontent>
<richcontent TYPE="NOTE"><html><head/><body><p>-- This is more about "Ceci est un test" --</p></body></html></richcontent>
</node>
</node>
</node>
<node CREATED="1248161883687" HGAP="-88" ID="ID_901848166" MODIFIED="1248162974171" POSITION="right" TEXT="Rebonjour" VSHIFT="76">
<node CREATED="1248161883687" HGAP="85" ID="ID_1570634894" MODIFIED="1248162978203" TEXT="Ceci est un autre test" VSHIFT="-109"/>
</node>
</node>
</map>

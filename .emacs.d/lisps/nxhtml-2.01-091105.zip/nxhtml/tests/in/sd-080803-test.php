<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <style type="text/css">
      table {
          border-collapse: collapse;
      }
    </style>
  </head>
  <body>
    <h1><?= $title ?></h1>
  </body>
</html>

